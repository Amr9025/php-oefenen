<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Resultaat</title>
</head>
<body>
    <h2>Uw ingevoerde tekst:</h2>
    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Vulnerable code - directly outputting user input
        echo $_POST['userInput'];
    }
    ?>
    <br><br>
    <a href="index.html">Terug naar formulier</a>
</body>
</html>