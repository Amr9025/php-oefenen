# Form Project

## Overview
This project consists of a simple HTML form that allows users to enter their name. The form submits the data to a PHP script for processing.

## Files
- `index.html`: Contains the HTML form with an input field for the user's name. It submits the data to `verwerk.php` using both the POST and GET methods.
- `verwerk.php`: Processes the input from the form and displays a greeting message.

## Usage
1. Open `index.html` in a web browser.
2. Enter your name in the input field.
3. Submit the form to see the greeting message displayed on the screen.

## Expected Output
When the form is submitted, the output will be in the format:
```
Goedemiddag, John Doe
```
Replace "John Doe" with the name you entered in the form.