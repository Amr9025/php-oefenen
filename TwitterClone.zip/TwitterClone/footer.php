<!-- filepath: /c:/xampp/htdocs/php-project/TwitterClone/includes/footer.php -->
<footer>
    <p>&copy; <?php echo date("Y"); ?> Chirpify. All rights reserved.</p>
</footer>