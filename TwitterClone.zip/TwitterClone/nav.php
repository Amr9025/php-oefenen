<!-- filepath: /c:/xampp/htdocs/php-project/TwitterClone/includes/nav.php -->
<aside class="sidebar">
    <div class="logo">
        <h2>Chirpify</h2>
    </div>
    <nav class="sidebar-nav">
        <a href="#" class="nav-item">Home</a>
        <a href="#" class="nav-item">Explore</a>
        <a href="#" class="nav-item">Notifications</a>
        <a href="#" class="nav-item">Messages</a>
        <a href="profile.php" class="nav-item active">Profile</a>
        <a href="index.php" class="nav-item">Logout</a>
    </nav>
    <button class="tweet-btn">Tweet</button>
</aside>